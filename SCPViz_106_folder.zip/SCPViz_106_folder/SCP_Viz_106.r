# The list of packages we'll require. Consider it our shiny toolbox.
required_packages <- c("shiny", "shinythemes", "plotly","FactoMineR", "factoextra", "imputeTS", "readxl", "ggplot2", "ggpubr", "readr", "dplyr", "tidyr", "gridExtra", "DT", "janitor", "shinycssloaders", "umap", "Rtsne")

for (pkg in required_packages) {
  if (!requireNamespace(pkg, quietly = TRUE)) install.packages(pkg)
  library(pkg, character.only = TRUE)
}

# ── EXAMPLE DATA CONFIGURATION ──────────────────────────────────────────────
# Place your example CSV in the same folder as app.R and set these values to
# match the column names / protein ID in that file.
EXAMPLE_FILE        <- "example_data.csv"   # path relative to app.R
EXAMPLE_KEYWORD     <- "pg_quantity"          # text that matches quan columns
EXAMPLE_PROTEIN_COL <- "pg_protein_groups"      # protein ID column header (pre-clean_names)
EXAMPLE_PROTEIN_ID  <- "P62805"             # protein to pre-load
EXAMPLE_N_COND      <- 2                    # number of conditions
EXAMPLE_CONDITIONS  <- c("H358", "HEP") # one string per condition
# ────────────────────────────────────────────────────────────────────────────

ui = navbarPage(
  title = "Single Cell Proteomics Vizualizer (SCP-Viz) 1.0.6",
  theme = shinytheme("flatly"),

  tabPanel("Main",
           sidebarLayout(
             sidebarPanel(
               # ── Logo ─────────────────────────────────────────────────────
               tags$img(src = "scpviz.png",
                        style = "width:100%; margin-bottom:12px;"),
               # ────────────────────────────────────────────────────────────

               # ── NEW: example data button ─────────────────────────────────
               actionButton("load_example", "📂 Load Example Data",
                            class = "btn-info",
                            style = "width:100%; margin-bottom:8px;"),
               tags$hr(),
               # ────────────────────────────────────────────────────────────

               fileInput("data_upload", "Upload CSV file", accept = NULL),
               checkboxInput("impute_zeros", "Would you like to impute N/A's?", value = FALSE),
               conditionalPanel(
                 condition = "input.impute_zeros == true",
                 radioButtons("imputation_method", "Choose imputation method:",
                              choices = c("Replace with zeros" = "zeros",
                                          "Background Noise" = "background_noise")),
                 selected = "zeros"),
               conditionalPanel(
                 condition = "input.imputation_method == 'background_noise'",
                 sliderInput("background_noise_level", "Choose Background Noise Level:",
                             min = 0, max = 10^4, value = 0)
               ),
               textInput("sample_keyword",
                         "Text used for quan columns (e.g., Abundance, Intensity, PG.Quantity)", value = ""),
               selectInput("protein_col", "Header for Protein or Peptide ID Column", choices = NULL),
               textInput("protein", "Enter Protein ID (Human Histone H4 is P62805, Mouse is P62806)", value = ""),
               numericInput("num_conditions",
                            "Number of Conditions (To merge conditions place 'or' between conditions)",
                            value = 1, min = 1),
               uiOutput("conditions_input"),
               actionButton("submit", "Unleash the Analysis",
                            class = "btn-primary", style = "width:100%")
             ),

             mainPanel(
               tabsetPanel(
                 tabPanel("Summary Table",
                          radioButtons("summary_choice", "Choose Summary Type:",
                                       choices = c("Group" = "group", "Individual" = "individual")),
                          DTOutput("summary_table")),
                 tabPanel("Selected Columns",
                          DTOutput("selected_columns")),
                 tabPanel("Bar Plot",
                          radioButtons("log2_choice_bar", "Choose Scale:",
                                       choices = c("Original" = "original", "Log2" = "log2")),
                          plotlyOutput("bar_plot"),
                          uiOutput("download_bar_plot_button_ui")),
                 tabPanel("Box Plot",
                          radioButtons("log2_choice_box", "Choose Scale:",
                                       choices = c("Original" = "original", "Log2" = "log2")),
                          plotOutput("box_plot")),
                 tabPanel("Histogram",
                          radioButtons("log2_choice_hist", "Choose Scale:",
                                       choices = c("Original" = "original", "Log2" = "log2")),
                          sliderInput("bin_height", "Choose Number of Bins:",
                                      min = 5, max = 250, value = 50),
                          plotlyOutput("hist_plot")),
                 tabPanel("Density Plot",
                          radioButtons("log2_choice_dens", "Choose Scale:",
                                       choices = c("Original" = "original", "Log2" = "log2")),
                          plotOutput("density_plot")),
                 tabPanel("Violin Plot",
                          radioButtons("log2_choice_violin", "Choose Scale:",
                                       choices = c("Original" = "original", "Log2" = "log2")),
                          plotlyOutput("violin_plot")),
                 tabPanel("Dimensionality Reduction",
                          radioButtons("dimred_method", "Choose Method:",
                                       choices = c("PCA", "UMAP", "t-SNE"),
                                       inline = TRUE),
                          radioButtons("log2_choice_pca", "Choose Scale:",
                                       choices = c("Original" = "original", "Log2" = "log2")),
                          conditionalPanel(
                            condition = "input.dimred_method == 't-SNE'",
                            sliderInput("tsne_perplexity", "t-SNE Perplexity:",
                                        min = 5, max = 50, value = 30)
                          ),
                          conditionalPanel(
                            condition = "input.dimred_method == 'UMAP'",
                            sliderInput("umap_neighbors", "UMAP N Neighbors:",
                                        min = 2, max = 50, value = 15)
                          ),
                          withSpinner(plotlyOutput("pca_plot")),
                          uiOutput("download_pca_plot_button_ui"))
               )
             )
           )
  ),

  tabPanel("User Guide",
           tags$h2("SCP Viz User Guide"),
           tags$p("Welcome to SCP Viz, an interactive data visualization platform tailored for analyzing and visualizing Single Cell Proteomics (SCP) data. Our tool is designed to be compatible with diverse analytical software, including Proteome Discoverer, Spectronaut, and FragPipe."),
           tags$h3("1. Uploading Dataset:"),
           tags$ul(
             tags$li("Upload your SCP data file through the ", tags$b("Upload CSV File"), " button in the UI. You can get our test datasets at  https://github.com/OrsburnLab-Pitt/SCPViz and a video tutorial can be found here https://www.youtube.com/watch?v=eK5RtNQMviY ")
           ),
           tags$h3("2. Imputation:"),
           tags$ul(
             tags$li("Activate the imputation option if you wish to impute missing values."),
             tags$li("Update your selection by clicking the ", tags$b("Unleash the Analysis"), " button."),
             tags$li("Choose whether to replace missing values with zeros or assign an arbitrary background noise level."),
             tags$li("Click ", tags$b("Unleash the Analysis"), " after each modification to apply the changes.")
           ),
           tags$h3("3. Quan Column Input:"),
           tags$ul(tags$li("Once the dataset is uploaded, specify the name of the quantification column in your output file, e.g., `Abundance`, `Intensity`, or `PG.Quantity`.")),
           tags$h3("4. Protein Id Column:"),
           tags$ul(tags$li("Select the appropriate column header for the Protein ID, e.g., `Accession` or `Protein ID`.")),
           tags$h3("5. Protein ID of Interest:"),
           tags$ul(tags$li("Enter the specific Protein ID you are interested in.")),
           tags$h3("6. Experiment Conditions:"),
           tags$ul(
             tags$li("Define the number of experimental conditions and enter them as they are labeled in the sample names."),
             tags$li("Use `or` to separate multiple names representing a single condition."),
             tags$li("Update your selection by clicking ", tags$b("Unleash the Analysis"), " when adjusting the number of conditions.")
           ),
           tags$h3("Tabs:"),
           tags$ul(
             tags$li(tags$b("Summary Table:"), " Provides a detailed summary of the groups being compared."),
             tags$li(tags$b("Selected Columns:"), " Confirm that the intended columns are included."),
             tags$li(tags$b("Individual Plots:"), " PCA, Bar, Box, Histogram, and Violin Plots are available.")
           ),
           tags$h3("Interacting with Graphs:"),
           tags$ul(tags$li("Graphs are interactive, allowing for enhanced insights via downloading, zooming, panning, selecting, auto-scaling, tooltips, and legend interaction.")),
           tags$h3("Data Transformation:"),
           tags$ul(tags$li("Opt for a Log2 transformed scale for a refined view of the dataset.")),
           tags$h3("Plot Selection:"),
           tags$ul(tags$li("Select points of interest on the PCA and Bar plots, hit ", tags$b("Unleash the Analysis"), ", then click ", tags$b("Download CSV"), " to generate a CSV containing the Protein IDs and selected samples for immediate analysis."))
  )
)

server = function(input, output, session) {
  options(shiny.maxRequestSize = Inf)

  # ── NEW: tracks whether we're using the bundled example ─────────────────
  use_example <- reactiveVal(FALSE)
  # ─────────────────────────────────────────────────────────────────────────

  # ── MODIFIED: data() now has two paths ───────────────────────────────────
  data <- reactive({
    if (use_example()) {
      # Load the bundled example file
      file <- read_csv(EXAMPLE_FILE, show_col_types = FALSE)
    } else {
      req(input$data_upload)
      filepath <- input$data_upload$datapath
      fileext  <- tools::file_ext(filepath)
      if (fileext == "csv") {
        file <- read_csv(filepath, show_col_types = FALSE)
      } else if (fileext == "tsv") {
        file <- read_delim(filepath, delim = "\t", show_col_types = FALSE)
        write_csv(file, "newfile.csv")
        file <- read_csv("newfile.csv", show_col_types = FALSE)
      } else if (fileext %in% c("xlsx", "xls")) {
        file <- read_excel(filepath)
        write_csv(file, "newfile.csv")
        file <- read_csv("newfile.csv", show_col_types = FALSE)
      } else {
        stop("Invalid file type")
      }
    }
    janitor::clean_names(file)
  })
  # ─────────────────────────────────────────────────────────────────────────

  # ── NEW: handle the example button ───────────────────────────────────────
  observeEvent(input$load_example, {
    # Validate the example file exists before switching
    if (!file.exists(EXAMPLE_FILE)) {
      showNotification(
        paste0("Example file '", EXAMPLE_FILE, "' not found. ",
               "Place it in the same folder as app.R."),
        type = "error", duration = 8
      )
      return()
    }

    use_example(TRUE)

    # Pre-fill all sidebar inputs with known example values
    updateTextInput(session,   "sample_keyword",  value = EXAMPLE_KEYWORD)
    updateTextInput(session,   "protein",         value = EXAMPLE_PROTEIN_ID)
    updateNumericInput(session, "num_conditions", value = EXAMPLE_N_COND)

    # Populate the protein_col dropdown from the example file
    file <- data()
    updateSelectInput(session, "protein_col",
                      choices  = names(file),
                      selected = janitor::make_clean_names(EXAMPLE_PROTEIN_COL))

    # Update condition inputs directly — the boxes already exist since the
    # default num_conditions matches EXAMPLE_N_COND, so no need to wait.
    for (i in seq_along(EXAMPLE_CONDITIONS)) {
      updateTextInput(session,
                      inputId = paste0("condition_", i),
                      value   = EXAMPLE_CONDITIONS[i])
    }

    showNotification("Example data loaded! Hit 'Unleash the Analysis' to run.",
                     type = "message", duration = 5)
  })
  # ─────────────────────────────────────────────────────────────────────────

  # ── MODIFIED: reset use_example when a real file is uploaded ─────────────
  observeEvent(input$data_upload, {
    use_example(FALSE)
    file <- data()
    updateSelectInput(session, "protein_col", choices = names(file))
  })
  # ─────────────────────────────────────────────────────────────────────────

  # ── MODIFIED: drop the hard req(input$data_upload) from selected_columns ─
  selected_columns <- reactive({
    req(input$sample_keyword)
    req(use_example() || !is.null(input$data_upload))
    selected <- grepl(input$sample_keyword, names(data()), ignore.case = TRUE)
    data.frame(column_name = names(data())[selected])
  })
  # ─────────────────────────────────────────────────────────────────────────

  output$selected_columns <- renderDT({ selected_columns() })

  organized_data <- reactive({
    req(input$protein_col)
    data() %>% select(input$protein_col, contains(input$sample_keyword))
  })

  df <- reactive({ data.frame(organized_data()) })

  df_long <- reactive({
    selected_col <- input$protein_col
    long_data <- df() %>%
      pivot_longer(cols = -all_of(selected_col), names_to = "Samples", values_to = "Intensity")
    if (input$impute_zeros) {
      if (input$imputation_method == "zeros") {
        long_data <- long_data %>% mutate(Intensity = ifelse(is.na(Intensity), 0, Intensity))
      } else if (input$imputation_method == "background_noise") {
        long_data <- long_data %>% mutate(Intensity = ifelse(is.na(Intensity), input$background_noise_level, Intensity))
      }
    }
    long_data
  })

  df_filtered <- reactive({
    req(input$protein)
    col_name <- input$protein_col
    df_long() %>% filter((!!as.name(col_name)) == input$protein)
  }) |> bindEvent(input$submit, ignoreNULL = FALSE, ignoreInit = FALSE)

  output$conditions_input <- renderUI({
    lapply(1:input$num_conditions, function(i) {
      current_val <- isolate(input[[paste0("condition_", i)]])
      textInput(inputId = paste0("condition_", i),
                label = paste0("Condition ", i),
                value = if (!is.null(current_val)) current_val else "")
    })
  })

  get_sample_type <- function(Samples, num_conditions, input) {
    conditions <- sapply(1:num_conditions, function(i) {
      condition_terms <- trimws(unlist(strsplit(tolower(input[[paste0("condition_", i)]]), split = " or ", fixed = TRUE)))
      any(sapply(condition_terms, function(x) grepl(paste0(x), Samples, ignore.case = TRUE)))
    })
    matched_condition <- match(TRUE, conditions, nomatch = NA)
    if (!is.na(matched_condition)) return(input[[paste0("condition_", matched_condition)]])
    return(NA)
  }

  df_filtered_with_color <- reactive({
    df_filtered() %>%
      rowwise() %>%
      mutate(Group = get_sample_type(Samples, input$num_conditions, input)) %>%
      ungroup()
  })

  condition_names <- reactive({ unique(na.omit(df_filtered_with_color()$Group)) })

  output$summary_table <- renderDT({
    if (input$summary_choice == "group") {
      summary_data <- df_filtered_with_color() %>%
        group_by(Group) %>%
        summarise(min = min(Intensity, na.rm = TRUE), max = max(Intensity, na.rm = TRUE),
                  median = round(median(Intensity, na.rm = TRUE), 2),
                  mean = round(mean(Intensity, na.rm = TRUE), 2),
                  SD = round(sd(Intensity, na.rm = TRUE), 2),
                  n_total = length(Intensity), n_missing = sum(is.na(Intensity)),
                  pct_missing = round(sum(is.na(Intensity)) / length(Intensity), 3),
                  n_values = sum(!is.na(Intensity)))
    } else {
      summary_data <- df_filtered() %>%
        group_by(Samples) %>%
        summarise(Abundance = sum(Intensity, na.rm = TRUE))
    }
    datatable(summary_data)
  })

  df_wide_with_color <- reactive({
    df_wide <- df_long() %>%
      group_by(Samples, !!sym(input$protein_col)) %>%
      slice(1) %>% ungroup() %>%
      filter(input$protein_col != "sp") %>%
      pivot_wider(names_from = !!sym(input$protein_col), values_from = Intensity) %>%
      select_if(~ !any(is.na(.)))
    if (input$log2_choice_pca == "log2") {
      df_wide <- df_wide %>% mutate(across(-Samples, ~ log2(. + 1)))
    }
    df_wide %>%
      mutate(Group = sapply(Samples, function(s) get_sample_type(s, input$num_conditions, input)),
             UniqueID = row_number())
  }) |> bindEvent(input$submit, ignoreNULL = FALSE, ignoreInit = FALSE)

  pca_data <- reactive({
    df_for_pca <- df_wide_with_color() %>% select(-Group, -UniqueID)
    mat <- as.matrix(df_for_pca[, -1])
    mat <- mat[, apply(mat, 2, var) > 0]

    method <- input$dimred_method

    if (method == "PCA") {
      res <- prcomp(mat, center = TRUE, scale. = TRUE)
      coords <- res$x[, 1:2]
      axis_labels <- c("PC1", "PC2")

    } else if (method == "UMAP") {
      cfg <- umap.defaults
      cfg$n_neighbors <- input$umap_neighbors
      res <- umap(mat, config = cfg)
      coords <- res$layout[, 1:2]
      axis_labels <- c("UMAP1", "UMAP2")

    } else if (method == "t-SNE") {
      # Rtsne requires n_obs > 3 * perplexity
      perp <- min(input$tsne_perplexity, floor((nrow(mat) - 1) / 3))
      res <- Rtsne(mat, dims = 2, perplexity = perp,
                   check_duplicates = FALSE, normalize = TRUE)
      coords <- res$Y
      axis_labels <- c("tSNE1", "tSNE2")
    }

    data.frame(Samples    = df_for_pca$Samples,
               Dim1       = coords[, 1],
               Dim2       = coords[, 2],
               Group      = df_wide_with_color()$Group,
               UniqueID   = df_wide_with_color()$UniqueID,
               axis1_lab  = axis_labels[1],
               axis2_lab  = axis_labels[2])
  })

  output$pca_plot <- renderPlotly({
    req(pca_data())
    pca_df <- pca_data()
    pca_plot <- ggplot(pca_df, aes(x = Dim1, y = Dim2, color = Group)) +
      geom_point(alpha = 0.7, size = 3, aes(customdata = Samples)) +
      theme_classic(base_size = 20) +
      labs(title = paste(input$dimred_method, "Plot"),
           x = pca_df$axis1_lab[1], y = pca_df$axis2_lab[1])
    ggplotly(pca_plot, source = "pcaPlot", tooltip = c("x", "y", "customdata"))
  })

  selected_pca_plot_points <- reactiveVal(data.frame())
  observe({
    selected_data <- event_data("plotly_selected", source = "pcaPlot")
    if (!is.null(selected_data)) {
      selected_samples <- selected_data$customdata
      selected_rows <- df_wide_with_color() %>% filter(Samples %in% selected_samples)
      selected_pca_plot_points(selected_rows)
    }
  })

  output$download_pca_plot_button_ui <- renderUI({
    if (!is.null(selected_pca_plot_points()) && nrow(selected_pca_plot_points()) > 0)
      downloadButton("downloadPCAPlotCSV", "Download Selected Points")
    else NULL
  })

  output$downloadPCAPlotCSV <- downloadHandler(
    filename = function() "selected_pca_plot_points.csv",
    content  = function(file) {
      selected_points <- selected_pca_plot_points()
      df_selected <- df() %>% select(all_of(c(input$protein_col, selected_points$Samples)))
      write_csv(df_selected, file)
    }
  )

  output$bar_plot <- renderPlotly({
    plot_data <- if (input$log2_choice_bar == "log2")
      df_filtered_with_color() %>% mutate(Intensity = log2(Intensity + 1))
    else df_filtered_with_color()
    bar_plotly <- ggplot(plot_data, aes(x = Samples, y = Intensity, fill = Group, customdata = Samples)) +
      geom_bar(stat = "identity", position = "dodge", width = 0.7) +
      facet_grid(cols = vars(Group)) + theme_classic(base_size = 12) +
      theme(axis.text.x = element_blank()) + labs(y = "Intensity")
    ggplotly(bar_plotly, source = "barPlot", tooltip = c("x", "y"))
  })

  selected_bar_plot_points <- reactiveVal(data.frame())
  observe({
    selected_data <- event_data("plotly_selected", source = "barPlot")
    if (!is.null(selected_data)) {
      selected_samples <- selected_data$customdata
      selected_rows <- df_wide_with_color() %>% filter(Samples %in% selected_samples)
      selected_bar_plot_points(selected_rows)
    }
  })

  output$download_bar_plot_button_ui <- renderUI({
    if (!is.null(selected_bar_plot_points()) && nrow(selected_bar_plot_points()) > 0)
      downloadButton("downloadBarPlotCSV", "Download Selected Points")
    else NULL
  })

  output$downloadBarPlotCSV <- downloadHandler(
    filename = function() "selected_bar_plot_points.csv",
    content  = function(file) {
      selected_points <- selected_bar_plot_points()
      df_selected <- df() %>% select(all_of(c(input$protein_col, selected_points$Samples)))
      write_csv(df_selected, file)
    }
  )

  output$box_plot <- renderPlot({
    plot_data <- if (input$log2_choice_box == "log2")
      df_filtered_with_color() %>% mutate(Intensity = log2(Intensity + 1))
    else df_filtered_with_color()
    my_comparisons <- list(c(condition_names()[1], condition_names()[2]))
    box_plot <- ggplot(plot_data, aes(x = Group, y = Intensity, fill = Group)) +
      geom_boxplot(width = 0.5) + geom_jitter(width = 0.2) +
      theme_classic(base_size = 14) +
      labs(x = "Group", y = paste("Intensity", unique(df_filtered()$protein_id))) +
      ggpubr::stat_compare_means(comparisons = my_comparisons, method = "t.test")
    print(box_plot)
  })

  output$hist_plot <- renderPlotly({
    plot_data <- if (input$log2_choice_hist == "log2")
      df_filtered_with_color() %>% mutate(Intensity = log2(Intensity + 1))
    else df_filtered_with_color()
    hist_plotly <- ggplot(plot_data, aes(x = Intensity, fill = Group)) +
      geom_histogram(bins = input$bin_height, color = "black") +
      theme_classic(base_size = 14) + labs(x = "Intensity", y = "Frequency")
    ggplotly(hist_plotly)
  })

  output$density_plot <- renderPlot({
    plot_data <- if (input$log2_choice_dens == "log2")
      df_filtered_with_color() %>% mutate(Intensity = log2(Intensity + 1))
    else df_filtered_with_color()
    density_plot <- ggplot(plot_data, aes(x = Intensity, fill = Group)) +
      geom_density(alpha = 0.5) + theme_classic(base_size = 16) +
      labs(x = "Intensity", y = "Density")
    print(density_plot)
  })

  output$violin_plot <- renderPlotly({
    req(df_filtered_with_color())
    plot_data <- if (input$log2_choice_violin == "log2")
      df_filtered_with_color() %>% mutate(Intensity = log2(Intensity + 1))
    else df_filtered_with_color()
    mean_sdl <- function(x, mult = 1) {
      data.frame(y = mean(x, na.rm = TRUE),
                 ymin = mean(x, na.rm = TRUE) - sd(x, na.rm = TRUE) * mult,
                 ymax = mean(x, na.rm = TRUE) + sd(x, na.rm = TRUE) * mult)
    }
    p_violin <- ggplot(plot_data, aes(x = Group, y = Intensity, fill = Group)) +
      geom_violin() +
      stat_summary(fun.data = mean_sdl, fun.args = list(mult = 1),
                   geom = "pointrange", color = "black", shape = 18, size = 0.75,
                   position = position_dodge(width = 0.9)) +
      labs(title = "Violin Plot", x = "Conditions",
           y = ifelse(input$log2_choice_violin == "log2", "Log2 Intensity", "Intensity")) +
      theme_minimal() +
      theme(text = element_text(size = 14), axis.title = element_text(size = 14),
            axis.text = element_text(size = 14), plot.title = element_text(size = 14, hjust = 0.5))
    ggplotly(p_violin)
  })
}

shinyApp(ui = ui, server = server)
