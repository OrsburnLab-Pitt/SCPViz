# The list of packages we'll require. Consider it our shiny toolbox.
required_packages <- c("shiny", "shinythemes", "plotly", "FactoMineR", "factoextra", "imputeTS", "readxl", "ggplot2", "ggpubr", "readr", "dplyr", "tidyr", "gridExtra", "DT", "janitor", "shinycssloaders", "umap", "Rtsne")

# If any package is missing, let's install it on-the-fly.
for (pkg in required_packages) {
  if (!requireNamespace(pkg, quietly = TRUE)) install.packages(pkg)
  # Load the package into our R session.
  library(pkg, character.only = TRUE)
}

# ── EXAMPLE DATA CONFIGURATION ──────────────────────────────────────────────
EXAMPLE_FILE        <- "example_data.csv"
EXAMPLE_KEYWORD     <- "pg_quantity"
EXAMPLE_PROTEIN_COL <- "PG_ProteinGroups"
EXAMPLE_PROTEIN_ID  <- "P62805"
EXAMPLE_N_COND      <- 2
EXAMPLE_CONDITIONS  <- c("H358", "HEP")
# ────────────────────────────────────────────────────────────────────────────

# Crafting the user interface for our app.
ui = navbarPage(

  # Naming our app. Make sure to pick a cool name, or else it won't work.
  title = "Single Cell Proteomics Vizualizer (SCP-Viz) 1.1",
  theme = shinytheme("flatly"),

  # Laying out the main structure: a sidebar for inputs and a main panel for outputs.
  tabPanel("Main",
           sidebarLayout(

             # The sidebar: where users tell us what they want. They are SO picky.
             sidebarPanel(

               # ── Logo ─────────────────────────────────────────────────────
               tags$img(src = "scpviz.png", style = "width:100%; margin-bottom:12px;"),

               # ── Example data button ──────────────────────────────────────
               actionButton("load_example", "📂 Load Example Data",
                            class = "btn-info", style = "width:100%; margin-bottom:8px;"),
               tags$hr(),

               fileInput("data_upload", "Upload CSV file", accept = NULL),
               checkboxInput("impute_zeros", "Would you like to impute N/A's?", value = FALSE),
               conditionalPanel(
                 condition = "input.impute_zeros == true",
                 radioButtons("imputation_method", "Choose imputation method:",
                              choices = c("Replace with zeros" = "zeros",
                                          "Background Noise"   = "background_noise")),
                 selected = "zeros"),
               conditionalPanel(
                 condition = "input.imputation_method == 'background_noise'",
                 sliderInput("background_noise_level", "Choose Background Noise Level:",
                             min = 0, max = 10^4, value = 0)
               ),
               selectInput("normalization_method", "Normalization Method:",
                           choices = c("None (raw)"                        = "none",
                                       "Median"                             = "median",
                                       "Total Ion Current (sum per sample)" = "tic",
                                       "Seurat Cell Size"                   = "seurat",
                                       "Reference Protein (e.g. Histone H4)" = "ref_protein")),
               conditionalPanel(
                 condition = "input.normalization_method == 'ref_protein'",
                 textInput("ref_protein_id",
                           "Reference Protein ID (e.g. P62805 for Human H4):",
                           value = "P62805")
               ),
               textInput("sample_keyword",
                         "Text used for quan columns (e.g., Abundance, Intensity, PG.Quantity)", value = ""),
               selectInput("protein_col", "Header for Protein or Peptide ID Column", choices = NULL),
               textInput("protein", "Enter Protein ID (Human Histone H4 is P62805, Mouse is P62806)", value = ""),
               numericInput("num_conditions",
                            "Number of Conditions (To merge conditions place 'or' between conditions)",
                            value = 2, min = 1),
               uiOutput("conditions_input"),
               actionButton("submit", "Unleash the Analysis",
                            class = "btn-primary", style = "width:100%")
             ),

             mainPanel(
               tabsetPanel(

                 tabPanel("Input Data Summary",
                          uiOutput("data_summary_ui")),

                 tabPanel("Summary Table",
                          radioButtons("summary_choice", "Choose Summary Type:",
                                       choices = c("Group" = "group", "Individual" = "individual")),
                          DTOutput("summary_table")),

                 tabPanel("Selected Columns",
                          DTOutput("selected_columns")),

                 tabPanel("Bar Plot",
                          radioButtons("log2_choice_bar", "Choose Scale:",
                                       choices = c("Original" = "original", "Log2" = "log2")),
                          plotlyOutput("bar_plot"),
                          uiOutput("download_bar_plot_button_ui"),
                          tags$hr(),
                          tags$b("Subpopulation Labeling"),
                          tags$p(tags$small("Select bars on the plot, type a label, then click Assign."),
                                 style = "color: grey;"),
                          textInput("subpop_label_bar", "New Subpopulation Label:", value = ""),
                          fluidRow(
                            column(6, actionButton("assign_label_bar", "Assign to Selected",
                                                   class = "btn-success", style = "width:100%")),
                            column(6, actionButton("clear_labels_bar", "Clear All Labels",
                                                   class = "btn-danger", style = "width:100%"))
                          ),
                          tags$br(),
                          uiOutput("download_subpop_bar_ui")),

                 tabPanel("Box Plot",
                          radioButtons("log2_choice_box", "Choose Scale:",
                                       choices = c("Original" = "original", "Log2" = "log2")),
                          plotOutput("box_plot")),

                 tabPanel("Histogram",
                          radioButtons("log2_choice_hist", "Choose Scale:",
                                       choices = c("Original" = "original", "Log2" = "log2")),
                          sliderInput("bin_height", "Choose Number of Bins:",
                                      min = 5, max = 250, value = 50),
                          plotlyOutput("hist_plot")),

                 tabPanel("Density Plot",
                          radioButtons("log2_choice_dens", "Choose Scale:",
                                       choices = c("Original" = "original", "Log2" = "log2")),
                          plotOutput("density_plot")),

                 tabPanel("Violin Plot",
                          radioButtons("log2_choice_violin", "Choose Scale:",
                                       choices = c("Original" = "original", "Log2" = "log2")),
                          plotlyOutput("violin_plot")),

                 # Dimensionality reduction tab — supports PCA, UMAP, and t-SNE.
                 tabPanel("Dimensionality Reduction",
                          radioButtons("dimred_method", "Choose Method:",
                                       choices = c("PCA", "UMAP", "t-SNE"), inline = TRUE),
                          radioButtons("log2_choice_pca", "Choose Scale:",
                                       choices = c("Original" = "original", "Log2" = "log2")),
                          conditionalPanel(
                            condition = "input.dimred_method == 't-SNE'",
                            sliderInput("tsne_perplexity", "t-SNE Perplexity:", min = 5, max = 50, value = 30)
                          ),
                          conditionalPanel(
                            condition = "input.dimred_method == 'UMAP'",
                            sliderInput("umap_neighbors", "UMAP N Neighbors:", min = 2, max = 50, value = 15)
                          ),
                          withSpinner(plotlyOutput("pca_plot")),
                          uiOutput("download_pca_plot_button_ui"),
                          tags$hr(),
                          tags$b("Subpopulation Labeling"),
                          tags$p(tags$small("Select points on the plot, type a label, then click Assign."),
                                 style = "color: grey;"),
                          textInput("subpop_label", "New Subpopulation Label:", value = ""),
                          fluidRow(
                            column(6, actionButton("assign_label", "Assign to Selected",
                                                   class = "btn-success", style = "width:100%")),
                            column(6, actionButton("clear_labels", "Clear All Labels",
                                                   class = "btn-danger", style = "width:100%"))
                          ),
                          tags$br(),
                          uiOutput("download_subpop_ui")),

                 # ── NEW: Volcano Plot tab ────────────────────────────────────
                 tabPanel("Volcano Plot",
                          tags$p(tags$small(
                            "Compare any two groups — including subpopulations you've labeled on other tabs."),
                            style = "color: grey; margin-top: 8px;"),
                          fluidRow(
                            column(4, selectInput("volcano_group_a", "Group A:", choices = NULL)),
                            column(4, selectInput("volcano_group_b", "Group B:", choices = NULL)),
                            column(4,
                                   numericInput("volcano_fc",  "Min |log2 FC|:", value = 1,   min = 0, step = 0.1),
                                   numericInput("volcano_pval","Max p-value:",   value = 0.05, min = 0, max = 1, step = 0.01)
                            )
                          ),
                          actionButton("run_volcano", "Run Volcano", class = "btn-primary"),
                          tags$br(), tags$br(),
                          withSpinner(plotlyOutput("volcano_plot", height = "600px")),
                          uiOutput("download_volcano_ui"))
                 # ────────────────────────────────────────────────────────────
               )
             )
           )
  ),

  tabPanel("User Guide",
           tags$h2("SCP Viz User Guide"),
           tags$p("Welcome to SCP Viz, an interactive data visualization platform tailored for analyzing and visualizing Single Cell Proteomics (SCP) data. Our tool is designed to be compatible with diverse analytical software, including Proteome Discoverer, Spectronaut, and FragPipe."),
           tags$h3("1. Uploading Dataset:"),
           tags$ul(
             tags$li("Upload your SCP data file through the ", tags$b("Upload CSV File"), " button in the UI. You can get our test datasets at  https://github.com/OrsburnLab-Pitt/SCPViz and a video tutorial can be found here https://www.youtube.com/watch?v=eK5RtNQMviY ")
           ),
           tags$h3("2. Imputation:"),
           tags$ul(
             tags$li("Activate the imputation option if you wish to impute missing values."),
             tags$li("Update your selection by clicking the ", tags$b("Unleash the Analysis"), " button."),
             tags$li("Choose whether to replace missing values with zeros or assign an arbitrary background noise level."),
             tags$li("Click ", tags$b("Unleash the Analysis"), " after each modification to apply the changes.")
           ),
           tags$h3("3. Quan Column Input:"),
           tags$ul(tags$li("Once the dataset is uploaded, specify the name of the quantification column in your output file, e.g., `Abundance`, `Intensity`, or `PG.Quantity`.")),
           tags$h3("4. Protein Id Column:"),
           tags$ul(tags$li("Select the appropriate column header for the Protein ID, e.g., `Accession` or `Protein ID`.")),
           tags$h3("5. Protein ID of Interest:"),
           tags$ul(tags$li("Enter the specific Protein ID you are interested in.")),
           tags$h3("6. Experiment Conditions:"),
           tags$ul(
             tags$li("Define the number of experimental conditions and enter them as they are labeled in the sample names."),
             tags$li("Use ` or ` (with spaces) to separate multiple names representing a single condition."),
             tags$li("Update your selection by clicking ", tags$b("Unleash the Analysis"), " when adjusting the number of conditions.")
           ),
           tags$h3("Tabs:"),
           tags$ul(
             tags$li(tags$b("Summary Table:"), " Provides a detailed summary of the groups being compared."),
             tags$li(tags$b("Selected Columns:"), " Confirm that the intended columns are included."),
             tags$li(tags$b("Individual Plots:"), " Dimensionality Reduction (PCA, UMAP, t-SNE), Bar, Box, Histogram, and Violin Plots are available."),
             tags$li(tags$b("Volcano Plot:"), " Compare any two groups or subpopulations across all proteins simultaneously. Significant hits are highlighted and the full results can be exported.")
           ),
           tags$h3("Subpopulation Labeling:"),
           tags$ul(
             tags$li("Select cells on the Dimensionality Reduction or Bar Plot using the box/lasso tool, type a label, and click Assign."),
             tags$li("Labels propagate immediately to all other plots."),
             tags$li("Labeled subpopulations also appear as selectable groups in the Volcano Plot.")
           ),
           tags$h3("Interacting with Graphs:"),
           tags$ul(tags$li("Graphs are interactive, allowing for enhanced insights via downloading, zooming, panning, selecting, auto-scaling, tooltips, and legend interaction.")),
           tags$h3("Data Transformation:"),
           tags$ul(tags$li("Opt for a Log2 transformed scale for a refined view of the dataset.")),
           tags$h3("Plot Selection:"),
           tags$ul(tags$li("Select points of interest on the Dimensionality Reduction and Bar plots, hit ", tags$b("Unleash the Analysis"), ", then click ", tags$b("Download CSV"), " to generate a CSV containing the Protein IDs and selected samples for immediate analysis."))
  )
)

# The 'server' is the backbone of our shiny app. It's where the magic happens!
server = function(input, output, session) {

  # Adjusting settings to allow large data uploads.
  options(shiny.maxRequestSize = Inf)

  # Tracks whether we're using the bundled example data.
  use_example <- reactiveVal(FALSE)

  # Dynamically reading the uploaded data and cleaning the column names.
  data <- reactive({
    if (use_example()) {
      file <- read_csv(EXAMPLE_FILE, show_col_types = FALSE)
    } else {
      req(input$data_upload)
      filepath <- input$data_upload$datapath
      fileext  <- tools::file_ext(filepath)
      if (fileext == "csv") {
        file <- read_csv(filepath, show_col_types = FALSE)
      } else if (fileext == "tsv") {
        file <- read_delim(filepath, delim = "\t", show_col_types = FALSE)
        write_csv(file, "newfile.csv")
        file <- read_csv("newfile.csv", show_col_types = FALSE)
      } else if (fileext %in% c("xlsx", "xls")) {
        file <- read_excel(filepath)
        write_csv(file, "newfile.csv")
        file <- read_csv("newfile.csv", show_col_types = FALSE)
      } else {
        stop("Invalid file type")
      }
    }
    janitor::clean_names(file)
  })

  # Handle the example data button.
  observeEvent(input$load_example, {
    if (!file.exists(EXAMPLE_FILE)) {
      showNotification(paste0("Example file '", EXAMPLE_FILE, "' not found. Place it in the same folder as app.R."),
                       type = "error", duration = 8)
      return()
    }
    use_example(TRUE)
    updateTextInput(session,    "sample_keyword", value = EXAMPLE_KEYWORD)
    updateTextInput(session,    "protein",        value = EXAMPLE_PROTEIN_ID)
    updateNumericInput(session, "num_conditions", value = EXAMPLE_N_COND)
    file <- data()
    updateSelectInput(session, "protein_col",
                      choices  = names(file),
                      selected = janitor::make_clean_names(EXAMPLE_PROTEIN_COL))
    for (i in seq_along(EXAMPLE_CONDITIONS)) {
      updateTextInput(session, inputId = paste0("condition_", i), value = EXAMPLE_CONDITIONS[i])
    }
    showNotification("Example data loaded! Hit 'Unleash the Analysis' to run.",
                     type = "message", duration = 5)
  })

  # Reset use_example when a real file is uploaded.
  observeEvent(input$data_upload, {
    use_example(FALSE)
    file <- data()
    updateSelectInput(session, "protein_col", choices = names(file))
  })

  # ── INPUT DATA SUMMARY ───────────────────────────────────────────────────
  # Summarizes the full uploaded dataset — not filtered to a single protein.
  input_summary <- reactive({
    req(df_long())
    long <- df_long()
    protein_col <- input$protein_col

    # Count detected molecules per cell (non-NA, non-zero intensities).
    per_cell <- long %>%
      filter(!is.na(Intensity), Intensity > 0) %>%
      group_by(Samples) %>%
      summarise(n_detected = n_distinct(!!sym(protein_col)), .groups = "drop")

    list(
      n_cells         = n_distinct(long$Samples),
      n_molecules     = n_distinct(long[[protein_col]]),
      mean_per_cell   = round(mean(per_cell$n_detected, na.rm = TRUE), 1),
      sd_per_cell     = round(sd(per_cell$n_detected,   na.rm = TRUE), 1),
      min_per_cell    = min(per_cell$n_detected,  na.rm = TRUE),
      max_per_cell    = max(per_cell$n_detected,  na.rm = TRUE),
      per_cell_tbl    = per_cell
    )
  })

  output$data_summary_ui <- renderUI({
    req(input_summary())
    s <- input_summary()

    tagList(
      tags$h3("Input Data Summary", style = "margin-top: 20px;"),
      tags$p(tags$small("Based on the full uploaded dataset after imputation and normalization."),
             style = "color: grey;"),
      tags$hr(),

      # ── Top-level stat boxes ─────────────────────────────────────────────
      fluidRow(
        column(4,
               tags$div(style = "background:#2980B9; color:white; border-radius:8px; padding:20px; text-align:center;",
                        tags$h2(s$n_cells,     style = "margin:0;"),
                        tags$p("Total Cells",  style = "margin:0; font-size: 14px;"))
        ),
        column(4,
               tags$div(style = "background:#27AE60; color:white; border-radius:8px; padding:20px; text-align:center;",
                        tags$h2(s$n_molecules,          style = "margin:0;"),
                        tags$p("Unique Molecules (Study-wide)", style = "margin:0; font-size: 14px;"))
        ),
        column(4,
               tags$div(style = "background:#8E44AD; color:white; border-radius:8px; padding:20px; text-align:center;",
                        tags$h2(s$mean_per_cell,                        style = "margin:0;"),
                        tags$p("Avg Molecules per Cell", style = "margin:0; font-size: 14px;"))
        )
      ),

      tags$br(),

      # ── Per-cell detection statistics ────────────────────────────────────
      tags$h4("Molecules Detected per Cell"),
      fluidRow(
        column(3,
               tags$div(style = "border: 1px solid #ddd; border-radius:6px; padding:14px; text-align:center;",
                        tags$h4(s$mean_per_cell, style = "margin:0; color:#2980B9;"),
                        tags$p("Mean", style = "margin:0; color:grey;"))
        ),
        column(3,
               tags$div(style = "border: 1px solid #ddd; border-radius:6px; padding:14px; text-align:center;",
                        tags$h4(s$sd_per_cell, style = "margin:0; color:#2980B9;"),
                        tags$p("Std Dev", style = "margin:0; color:grey;"))
        ),
        column(3,
               tags$div(style = "border: 1px solid #ddd; border-radius:6px; padding:14px; text-align:center;",
                        tags$h4(s$min_per_cell, style = "margin:0; color:#2980B9;"),
                        tags$p("Min", style = "margin:0; color:grey;"))
        ),
        column(3,
               tags$div(style = "border: 1px solid #ddd; border-radius:6px; padding:14px; text-align:center;",
                        tags$h4(s$max_per_cell, style = "margin:0; color:#2980B9;"),
                        tags$p("Max", style = "margin:0; color:grey;"))
        )
      ),

      tags$br(),

      # ── Per-cell detection distribution plot ─────────────────────────────
      tags$h4("Distribution of Molecules Detected per Cell"),
      plotlyOutput("summary_hist", height = "300px"),

      tags$br(),

      # ── Per-cell table ───────────────────────────────────────────────────
      tags$h4("Per-Cell Detection Table"),
      DTOutput("summary_per_cell_tbl")
    )
  })

  # Histogram of molecules detected per cell.
  output$summary_hist <- renderPlotly({
    req(input_summary())
    tbl <- input_summary()$per_cell_tbl
    p <- ggplot(tbl, aes(x = n_detected)) +
      geom_histogram(bins = 40, fill = "#2980B9", color = "white", alpha = 0.85) +
      theme_classic(base_size = 13) +
      labs(x = "Molecules Detected", y = "Number of Cells")
    ggplotly(p)
  })

  # Searchable per-cell table.
  output$summary_per_cell_tbl <- renderDT({
    req(input_summary())
    datatable(
      input_summary()$per_cell_tbl %>%
        rename(Cell = Samples, `Molecules Detected` = n_detected) %>%
        arrange(desc(`Molecules Detected`)),
      options = list(pageLength = 10)
    )
  })
  # ─────────────────────────────────────────────────────────────────────────

  # Select the appropriate columns from the uploaded CSV.
  selected_columns <- reactive({
    req(input$sample_keyword)
    req(use_example() || !is.null(input$data_upload))
    selected <- grepl(input$sample_keyword, names(data()), ignore.case = TRUE)
    data.frame(column_name = names(data())[selected])
  })

  output$selected_columns <- renderDT({ selected_columns() })

  # Organize the data to get it ready for visualization.
  organized_data <- reactive({
    req(input$protein_col)
    data() %>% select(input$protein_col, contains(input$sample_keyword))
  })

  # For some visuals, we need the data in a dataframe format.
  df <- reactive({ data.frame(organized_data()) })

  # Convert our data to a 'long' format which is preferable for certain visualizations.
  df_long <- reactive({
    selected_col <- input$protein_col
    long_data <- df() %>%
      pivot_longer(cols = -all_of(selected_col), names_to = "Samples", values_to = "Intensity")

    # Check and handle missing data based on user's preference.
    if (input$impute_zeros) {
      if (input$imputation_method == "zeros") {
        long_data <- long_data %>% mutate(Intensity = ifelse(is.na(Intensity), 0, Intensity))
      } else if (input$imputation_method == "background_noise") {
        long_data <- long_data %>% mutate(Intensity = ifelse(is.na(Intensity), input$background_noise_level, Intensity))
      }
    }

    # Apply normalization across samples based on user's preference.
    long_data <- switch(input$normalization_method,
      "median" = {
        global_median <- median(long_data$Intensity, na.rm = TRUE)
        long_data %>%
          group_by(Samples) %>%
          mutate(Intensity = Intensity / median(Intensity, na.rm = TRUE) * global_median) %>%
          ungroup()
      },
      "tic" = {
        mean_total <- mean(
          long_data %>% group_by(Samples) %>%
            summarise(total = sum(Intensity, na.rm = TRUE)) %>% pull(total)
        )
        long_data %>%
          group_by(Samples) %>%
          mutate(Intensity = Intensity / sum(Intensity, na.rm = TRUE) * mean_total) %>%
          ungroup()
      },
      "seurat" = {
        long_data %>%
          group_by(Samples) %>%
          mutate(Intensity = log1p(Intensity / sum(Intensity, na.rm = TRUE) * 10000)) %>%
          ungroup()
      },
      long_data
    )

    long_data
  })

  # Filtering the long dataframe based on the protein selection by the user.
  df_filtered <- reactive({
    req(input$protein)
    col_name <- input$protein_col
    df_long() %>% filter((!!as.name(col_name)) == input$protein)
  }) |> bindEvent(input$submit, ignoreNULL = FALSE, ignoreInit = FALSE)

  # Render input fields dynamically based on the number of conditions specified by the user.
  output$conditions_input <- renderUI({
    lapply(1:input$num_conditions, function(i) {
      current_val <- isolate(input[[paste0("condition_", i)]])
      textInput(inputId = paste0("condition_", i), label = paste0("Condition ", i),
                value = if (!is.null(current_val)) current_val else "")
    })
  })

  # This function identifies the sample type based on user-defined conditions.
  get_sample_type <- function(Samples, num_conditions, input) {
    conditions <- sapply(1:num_conditions, function(i) {
      condition_terms <- trimws(unlist(strsplit(tolower(input[[paste0("condition_", i)]]), split = " or ", fixed = TRUE)))
      any(sapply(condition_terms, function(x) grepl(paste0(x), Samples, ignore.case = TRUE)))
    })
    matched_condition <- match(TRUE, conditions, nomatch = NA)
    if (!is.na(matched_condition)) return(input[[paste0("condition_", matched_condition)]])
    return(NA)
  }

  # Extend the filtered data to include color assignments based on sample group.
  df_filtered_with_color <- reactive({
    df_filtered() %>%
      rowwise() %>%
      mutate(Group = get_sample_type(Samples, input$num_conditions, input)) %>%
      ungroup()
  })

  # Reactive function to retrieve the unique condition names, omitting any NA values.
  condition_names <- reactive({ unique(na.omit(df_filtered_with_color()$Group)) })

  # Generate a summary table.
  output$summary_table <- renderDT({
    if (input$summary_choice == "group") {
      summary_data <- df_filtered_with_color() %>%
        group_by(Group) %>%
        summarise(min = min(Intensity, na.rm = TRUE), max = max(Intensity, na.rm = TRUE),
                  median = round(median(Intensity, na.rm = TRUE), 2),
                  mean = round(mean(Intensity, na.rm = TRUE), 2),
                  SD = round(sd(Intensity, na.rm = TRUE), 2),
                  n_total = length(Intensity), n_missing = sum(is.na(Intensity)),
                  pct_missing = round(sum(is.na(Intensity)) / length(Intensity), 3),
                  n_values = sum(!is.na(Intensity)))
    } else {
      summary_data <- df_filtered() %>%
        group_by(Samples) %>%
        summarise(Abundance = sum(Intensity, na.rm = TRUE))
    }
    datatable(summary_data)
  })

  # Create a reactive for wide format data — used for dim reduction and volcano.
  df_wide_with_color <- reactive({
    df_wide <- df_long() %>%
      group_by(Samples, !!sym(input$protein_col)) %>%
      slice(1) %>% ungroup() %>%
      filter(input$protein_col != "sp") %>%
      pivot_wider(names_from = !!sym(input$protein_col), values_from = Intensity) %>%
      select_if(~ !any(is.na(.)))
    if (input$log2_choice_pca == "log2") {
      df_wide <- df_wide %>% mutate(across(-Samples, ~ log2(. + 1)))
    }
    df_wide %>%
      mutate(Group    = sapply(Samples, function(s) get_sample_type(s, input$num_conditions, input)),
             UniqueID = row_number())
  }) |> bindEvent(input$submit, ignoreNULL = FALSE, ignoreInit = FALSE)

  # ── SUBPOPULATION LABELS ─────────────────────────────────────────────────
  # Shared reactive pool — all tabs read from and write to this.
  subpop_labels <- reactiveVal(data.frame(Samples = character(), Subpopulation = character()))

  # Helper: merge new labels into the pool, overwriting any existing ones for those cells.
  assign_labels <- function(samples, label) {
    new_labels <- data.frame(Samples = samples, Subpopulation = label, stringsAsFactors = FALSE)
    updated <- subpop_labels() %>%
      filter(!Samples %in% new_labels$Samples) %>%
      bind_rows(new_labels)
    subpop_labels(updated)
    showNotification(paste0(length(samples), " cell(s) labeled as '", label, "'"),
                     type = "message", duration = 3)
  }

  # Assign from dim reduction plot.
  observeEvent(input$assign_label, {
    req(input$subpop_label)
    selected_data <- event_data("plotly_selected", source = "pcaPlot")
    req(selected_data)
    assign_labels(selected_data$customdata, input$subpop_label)
  })

  # Assign from bar plot.
  observeEvent(input$assign_label_bar, {
    req(input$subpop_label_bar)
    selected_data <- event_data("plotly_selected", source = "barPlot")
    req(selected_data)
    assign_labels(selected_data$customdata, input$subpop_label_bar)
  })

  # Clear all labels — shared across all tabs.
  observeEvent(input$clear_labels,     { subpop_labels(data.frame(Samples = character(), Subpopulation = character())); showNotification("All subpopulation labels cleared.", type = "warning", duration = 3) })
  observeEvent(input$clear_labels_bar, { subpop_labels(data.frame(Samples = character(), Subpopulation = character())); showNotification("All subpopulation labels cleared.", type = "warning", duration = 3) })

  # Helper: join subpop labels into a plot_data frame, returning ColorBy and color_title.
  apply_subpop_colors <- function(plot_data) {
    labels <- subpop_labels()
    if (nrow(labels) > 0) {
      plot_data <- plot_data %>%
        left_join(labels, by = "Samples") %>%
        mutate(ColorBy = ifelse(is.na(Subpopulation), Group, Subpopulation))
      list(data = plot_data, title = "Subpopulation")
    } else {
      plot_data$ColorBy <- plot_data$Group
      list(data = plot_data, title = "Group")
    }
  }

  # ── ALL AVAILABLE GROUPS (conditions + subpopulations) ───────────────────
  # Used to populate the volcano plot dropdowns.
  all_groups <- reactive({
    base   <- unique(na.omit(condition_names()))
    subpop <- unique(na.omit(subpop_labels()$Subpopulation))
    unique(c(base, subpop))
  })

  # Update volcano dropdowns whenever the available groups change.
  observe({
    grps <- all_groups()
    updateSelectInput(session, "volcano_group_a", choices = grps, selected = grps[1])
    updateSelectInput(session, "volcano_group_b", choices = grps, selected = grps[min(2, length(grps))])
  })
  # ─────────────────────────────────────────────────────────────────────────

  # ── VOLCANO PLOT ─────────────────────────────────────────────────────────
  # Compute fold change and p-value for every protein between two selected groups.
  volcano_data <- reactive({
    req(input$volcano_group_a, input$volcano_group_b)
    req(input$volcano_group_a != input$volcano_group_b)

    # Build a sample → group lookup combining original conditions and subpop labels.
    wide   <- df_wide_with_color()
    labels <- subpop_labels()

    sample_groups <- wide %>%
      select(Samples, Group) %>%
      left_join(labels, by = "Samples") %>%
      mutate(FinalGroup = ifelse(!is.na(Subpopulation), Subpopulation, Group))

    grp_a <- input$volcano_group_a
    grp_b <- input$volcano_group_b

    samples_a <- sample_groups %>% filter(FinalGroup == grp_a) %>% pull(Samples)
    samples_b <- sample_groups %>% filter(FinalGroup == grp_b) %>% pull(Samples)

    req(length(samples_a) >= 2, length(samples_b) >= 2)

    # Work on all proteins in long format (unfiltered).
    long <- df_long()
    protein_col <- input$protein_col

    long %>%
      filter(Samples %in% c(samples_a, samples_b)) %>%
      mutate(FinalGroup = ifelse(Samples %in% samples_a, grp_a, grp_b)) %>%
      group_by(!!sym(protein_col)) %>%
      summarise(
        mean_a   = mean(Intensity[FinalGroup == grp_a], na.rm = TRUE),
        mean_b   = mean(Intensity[FinalGroup == grp_b], na.rm = TRUE),
        log2FC   = log2((mean_a + 1) / (mean_b + 1)),
        p_value  = tryCatch(
          t.test(Intensity[FinalGroup == grp_a],
                 Intensity[FinalGroup == grp_b])$p.value,
          error = function(e) NA_real_
        ),
        .groups = "drop"
      ) %>%
      filter(!is.na(p_value)) %>%
      mutate(
        neg_log10_p = -log10(p_value),
        Significant = abs(log2FC) >= input$volcano_fc & p_value <= input$volcano_pval,
        Direction   = case_when(
          Significant & log2FC > 0  ~ paste0("Up in ", grp_a),
          Significant & log2FC < 0  ~ paste0("Up in ", grp_b),
          TRUE                       ~ "Not significant"
        )
      )
  }) |> bindEvent(input$run_volcano)

  # Render the volcano plot.
  output$volcano_plot <- renderPlotly({
    req(volcano_data())
    vdf <- volcano_data()
    protein_col <- input$protein_col

    # Build color vector dynamically — named vectors require literal names,
    # so we construct it before passing to scale_color_manual().
    color_vals <- c("grey70", "#E74C3C", "#2E86C1")
    names(color_vals) <- c("Not significant",
                           paste0("Up in ", input$volcano_group_a),
                           paste0("Up in ", input$volcano_group_b))

    p <- ggplot(vdf, aes(x = log2FC, y = neg_log10_p, color = Direction,
                         text = paste0("Protein: ", !!sym(protein_col),
                                       "<br>log2FC: ", round(log2FC, 3),
                                       "<br>p-value: ", signif(p_value, 3)))) +
      geom_point(alpha = 0.7, size = 2) +
      scale_color_manual(values = color_vals) +
      geom_vline(xintercept = c(-input$volcano_fc, input$volcano_fc),
                 linetype = "dashed", color = "grey40") +
      geom_hline(yintercept = -log10(input$volcano_pval),
                 linetype = "dashed", color = "grey40") +
      theme_classic(base_size = 14) +
      labs(title = paste0("Volcano: ", input$volcano_group_a, " vs ", input$volcano_group_b),
           x = paste0("log2 FC (", input$volcano_group_a, " / ", input$volcano_group_b, ")"),
           y = "-log10(p-value)", color = "")

    ggplotly(p, tooltip = "text")
  })

  # Show download button once volcano data exists.
  output$download_volcano_ui <- renderUI({
    req(volcano_data())
    downloadButton("download_volcano_csv", "⬇ Download Volcano Results")
  })

  # Export the full volcano results table as CSV.
  output$download_volcano_csv <- downloadHandler(
    filename = function() paste0("volcano_", input$volcano_group_a, "_vs_", input$volcano_group_b, ".csv"),
    content  = function(file) write_csv(volcano_data(), file)
  )
  # ─────────────────────────────────────────────────────────────────────────

  # ── DIMENSIONALITY REDUCTION ─────────────────────────────────────────────
  selected_pca_plot_points <- reactiveVal(data.frame())

  pca_data <- reactive({
    df_for_pca <- df_wide_with_color() %>% select(-Group, -UniqueID)
    mat <- as.matrix(df_for_pca[, -1])
    mat <- mat[, apply(mat, 2, var) > 0]
    method <- input$dimred_method
    if (method == "PCA") {
      res <- prcomp(mat, center = TRUE, scale. = TRUE)
      coords <- res$x[, 1:2]; axis_labels <- c("PC1", "PC2")
    } else if (method == "UMAP") {
      cfg <- umap.defaults; cfg$n_neighbors <- input$umap_neighbors
      res <- umap(mat, config = cfg)
      coords <- res$layout[, 1:2]; axis_labels <- c("UMAP1", "UMAP2")
    } else if (method == "t-SNE") {
      perp <- min(input$tsne_perplexity, floor((nrow(mat) - 1) / 3))
      res  <- Rtsne(mat, dims = 2, perplexity = perp, check_duplicates = FALSE, normalize = TRUE)
      coords <- res$Y; axis_labels <- c("tSNE1", "tSNE2")
    }
    data.frame(Samples = df_for_pca$Samples, Dim1 = coords[, 1], Dim2 = coords[, 2],
               Group = df_wide_with_color()$Group, UniqueID = df_wide_with_color()$UniqueID,
               axis1_lab = axis_labels[1], axis2_lab = axis_labels[2])
  })

  output$pca_plot <- renderPlotly({
    req(pca_data())
    pca_df  <- pca_data()
    colored <- apply_subpop_colors(pca_df)
    p <- ggplot(colored$data, aes(x = Dim1, y = Dim2, color = ColorBy)) +
      geom_point(alpha = 0.7, size = 3, aes(customdata = Samples)) +
      theme_classic(base_size = 20) +
      labs(title = paste(input$dimred_method, "Plot"), color = colored$title,
           x = pca_df$axis1_lab[1], y = pca_df$axis2_lab[1])
    ggplotly(p, source = "pcaPlot", tooltip = c("x", "y", "customdata"))
  })

  observe({
    selected_data <- event_data("plotly_selected", source = "pcaPlot")
    if (!is.null(selected_data)) {
      selected_rows <- df_wide_with_color() %>% filter(Samples %in% selected_data$customdata)
      selected_pca_plot_points(selected_rows)
    }
  })

  output$download_pca_plot_button_ui <- renderUI({
    if (!is.null(selected_pca_plot_points()) && nrow(selected_pca_plot_points()) > 0)
      downloadButton("downloadPCAPlotCSV", "Download Selected Points")
    else NULL
  })

  output$downloadPCAPlotCSV <- downloadHandler(
    filename = function() "selected_pca_plot_points.csv",
    content  = function(file) {
      df_selected <- df() %>% select(all_of(c(input$protein_col, selected_pca_plot_points()$Samples)))
      write_csv(df_selected, file)
    }
  )

  output$download_subpop_ui <- renderUI({
    if (nrow(subpop_labels()) > 0) downloadButton("downloadSubpop", "⬇ Export Labeled Data") else NULL
  })

  output$downloadSubpop <- downloadHandler(
    filename = function() "labeled_subpopulations.csv",
    content  = function(file) {
      write_csv(df_wide_with_color() %>% select(-UniqueID) %>% left_join(subpop_labels(), by = "Samples"), file)
    }
  )

  # ── BAR PLOT ─────────────────────────────────────────────────────────────
  selected_bar_plot_points <- reactiveVal(data.frame())

  output$bar_plot <- renderPlotly({
    plot_data <- if (input$log2_choice_bar == "log2")
      df_filtered_with_color() %>% mutate(Intensity = log2(Intensity + 1))
    else df_filtered_with_color()
    colored <- apply_subpop_colors(plot_data)
    bar_plotly <- ggplot(colored$data, aes(x = Samples, y = Intensity, fill = ColorBy, customdata = Samples)) +
      geom_bar(stat = "identity", position = "dodge", width = 0.7) +
      facet_grid(cols = vars(Group)) + theme_classic(base_size = 12) +
      theme(axis.text.x = element_blank()) + labs(y = "Intensity", fill = colored$title)
    ggplotly(bar_plotly, source = "barPlot", tooltip = c("x", "y"))
  })

  observe({
    selected_data <- event_data("plotly_selected", source = "barPlot")
    if (!is.null(selected_data)) {
      selected_rows <- df_wide_with_color() %>% filter(Samples %in% selected_data$customdata)
      selected_bar_plot_points(selected_rows)
    }
  })

  output$download_bar_plot_button_ui <- renderUI({
    if (!is.null(selected_bar_plot_points()) && nrow(selected_bar_plot_points()) > 0)
      downloadButton("downloadBarPlotCSV", "Download Selected Points")
    else NULL
  })

  output$downloadBarPlotCSV <- downloadHandler(
    filename = function() "selected_bar_plot_points.csv",
    content  = function(file) {
      df_selected <- df() %>% select(all_of(c(input$protein_col, selected_bar_plot_points()$Samples)))
      write_csv(df_selected, file)
    }
  )

  output$download_subpop_bar_ui <- renderUI({
    if (nrow(subpop_labels()) > 0) downloadButton("downloadSubpopBar", "⬇ Export Labeled Data") else NULL
  })

  output$downloadSubpopBar <- downloadHandler(
    filename = function() "labeled_subpopulations.csv",
    content  = function(file) {
      write_csv(df_wide_with_color() %>% select(-UniqueID) %>% left_join(subpop_labels(), by = "Samples"), file)
    }
  )

  # ── BOX PLOT ─────────────────────────────────────────────────────────────
  output$box_plot <- renderPlot({
    plot_data <- if (input$log2_choice_box == "log2")
      df_filtered_with_color() %>% mutate(Intensity = log2(Intensity + 1))
    else df_filtered_with_color()
    colored <- apply_subpop_colors(plot_data)
    current_groups  <- unique(na.omit(colored$data$ColorBy))
    my_comparisons  <- if (length(current_groups) >= 2) combn(current_groups, 2, simplify = FALSE) else list()
    box_plot <- ggplot(colored$data, aes(x = ColorBy, y = Intensity, fill = ColorBy)) +
      geom_boxplot(width = 0.5) + geom_jitter(width = 0.2) +
      theme_classic(base_size = 14) +
      labs(x = colored$title, fill = colored$title,
           y = paste("Intensity", unique(df_filtered()$protein_id)))
    if (length(my_comparisons) > 0)
      box_plot <- box_plot + ggpubr::stat_compare_means(comparisons = my_comparisons, method = "t.test")
    print(box_plot)
  })

  # ── HISTOGRAM ────────────────────────────────────────────────────────────
  output$hist_plot <- renderPlotly({
    plot_data <- if (input$log2_choice_hist == "log2")
      df_filtered_with_color() %>% mutate(Intensity = log2(Intensity + 1))
    else df_filtered_with_color()
    colored <- apply_subpop_colors(plot_data)
    hist_plotly <- ggplot(colored$data, aes(x = Intensity, fill = ColorBy)) +
      geom_histogram(bins = input$bin_height, color = "black") +
      theme_classic(base_size = 14) + labs(x = "Intensity", y = "Frequency", fill = colored$title)
    ggplotly(hist_plotly)
  })

  # ── DENSITY PLOT ─────────────────────────────────────────────────────────
  output$density_plot <- renderPlot({
    plot_data <- if (input$log2_choice_dens == "log2")
      df_filtered_with_color() %>% mutate(Intensity = log2(Intensity + 1))
    else df_filtered_with_color()
    density_plot <- ggplot(plot_data, aes(x = Intensity, fill = Group)) +
      geom_density(alpha = 0.5) + theme_classic(base_size = 16) +
      labs(x = "Intensity", y = "Density")
    print(density_plot)
  })

  # ── VIOLIN PLOT ───────────────────────────────────────────────────────────
  output$violin_plot <- renderPlotly({
    req(df_filtered_with_color())
    plot_data <- if (input$log2_choice_violin == "log2")
      df_filtered_with_color() %>% mutate(Intensity = log2(Intensity + 1))
    else df_filtered_with_color()
    mean_sdl <- function(x, mult = 1) {
      data.frame(y = mean(x, na.rm = TRUE),
                 ymin = mean(x, na.rm = TRUE) - sd(x, na.rm = TRUE) * mult,
                 ymax = mean(x, na.rm = TRUE) + sd(x, na.rm = TRUE) * mult)
    }
    p_violin <- ggplot(plot_data, aes(x = Group, y = Intensity, fill = Group)) +
      geom_violin() +
      stat_summary(fun.data = mean_sdl, fun.args = list(mult = 1),
                   geom = "pointrange", color = "black", shape = 18, size = 0.75,
                   position = position_dodge(width = 0.9)) +
      labs(title = "Violin Plot", x = "Conditions",
           y = ifelse(input$log2_choice_violin == "log2", "Log2 Intensity", "Intensity")) +
      theme_minimal() +
      theme(text = element_text(size = 14), axis.title = element_text(size = 14),
            axis.text = element_text(size = 14), plot.title = element_text(size = 14, hjust = 0.5))
    ggplotly(p_violin)
  })
}

# Run the app ----
shinyApp(ui = ui, server = server)
